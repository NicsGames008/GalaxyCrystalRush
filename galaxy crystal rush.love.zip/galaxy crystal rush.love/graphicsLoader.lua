

function loadGraphics()
    love.graphics.setBackgroundColor(0.545, 0.824, 0.996)
    background = love.graphics.newImage("background.png")
end